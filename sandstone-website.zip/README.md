# Sandstone Website

Simple HTML & CSS website with a sandstone-inspired theme.

## Features
- Warm earthy colors
- Minimal layout
- Easy to customize

## How to Run
Open index.html in your browser.

## Author
Generated with ChatGPT
